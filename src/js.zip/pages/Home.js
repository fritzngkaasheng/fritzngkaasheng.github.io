"use strict";

const Home = () => {
  return /*#__PURE__*/React.createElement("h1", null, "Home");
};
export default Home; 
