"use strict";

const NoPage = () => {
  return /*#__PURE__*/React.createElement("h1", null, "404");
};
export default NoPage; 
