"use strict";

const Blogs = () => {
  return /*#__PURE__*/React.createElement("h1", null, "Blog Articles");
};
export default Blogs; 
