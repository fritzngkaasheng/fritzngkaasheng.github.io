"use strict";

const Contact = () => {
  return /*#__PURE__*/React.createElement("h1", null, "Contact Me");
};
export default Contact; 
